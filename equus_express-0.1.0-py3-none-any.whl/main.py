def main():
    print("Hello from equus-express!")


if __name__ == "__main__":
    main()
